﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MiddleTier.DataSet1TableAdapters;
using MiddleTier;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
       
        private void button1_Click(object sender, EventArgs e)
        {

            DataSet1 ds1 = new DataSet1();
            Purchase_RequestsTableAdapter PRTadapter = new Purchase_RequestsTableAdapter();
            //PRTadapter.GetBasicAll();

            PRTadapter.Fill(ds1.Purchase_Requests);
            PRTadapter.GetData();
            //PRTadapter.FillBy1(ds1.Purchase_Requests);
            dataGridView1.DataSource = ds1.Purchase_Requests;
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
