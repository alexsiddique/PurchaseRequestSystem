﻿namespace WindowsFormsApplication1
{


    partial class Purchase_Request_SystemDataSet
    {
    }
}

namespace WindowsFormsApplication1.Purchase_Request_SystemDataSetTableAdapters {
    
    
    public partial class Purchase_RequestsTableAdapter {
    }
}
