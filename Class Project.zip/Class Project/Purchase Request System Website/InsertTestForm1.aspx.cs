﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class InsertTestForm1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Submit_ServerClick(object sender, EventArgs e)
    {
        //Insert form data into database
        SqlDataSource1.Insert();

        //Clear client side HTML form elements after inserting data            
        //ShortDescription.Value = "";
        //Justification.Value = "";
        //firstname.Value = "";
        //lastname.Value = "";
        //Phone.Value = "";
        //email.Value = "";


    }
}