﻿$('#nrf').click(function () {
    window.location.href = "NewRequestDataEntryForm.aspx";
});


$('#rrp').click(function () {
    window.location.href = "RequestReviewPage.aspx";
});

$('#vp').click(function () {
    window.location.href = "VendorPage.aspx";
});

$('#cip').click(function () {
    window.location.href = "CatalogItemsPage.aspx"
});

$('#map').click(function () {
    window.location.href = "ManagerApprovalPage.aspx"
});
//$(function () {
//    $("#datepicker").datepicker();
//});





$(document).ready(function () {
    //alert("this ran 1");

    var url = window.location.pathname.split("/").pop();
    //alert(url + "first");
    if (url == '') {
        url = 'home.html';
    }
    //alert(url);
    //$('li a[href="' + url + '"]').addClass('active');
    //$('.nav.navbar-nav a[href="' + url + '"]').addClass('active');
    //$('ul.nav navbar-nav li a[href="' + url + '"]').addClass('active');

    //$('#vp a[href="' + url + '"]').parent().addClass('active');
    $('li a[href="' + url + '"]').parent().addClass('active');
    //alert("this ran");
});