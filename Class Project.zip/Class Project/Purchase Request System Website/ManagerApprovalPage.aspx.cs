﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MiddleTier.DataSet1TableAdapters;
using MiddleTier;

public partial class ManagerApprovalPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

      
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}