﻿namespace MiddleTier
{


    partial class DataSet1
    {
    }
}

namespace MiddleTier.DataSet1TableAdapters {
    
    
    public partial class Purchase_RequestsTableAdapter {
    }
}
